/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author FURIOUS
 */
public class HourList {

    private static final String[] HOUR_LIST = {
        "GMT 00:00", "GMT 01:00", "GMT 02:00", "GMT 03:00",
        "GMT 04:00", "GMT 05:00", "GMT 06:00", "GMT 07:00",
        "GMT 08:00", "GMT 09:00", "GMT 10:00", "GMT 11:00",
        "GMT 12:00", "GMT 13:00", "GMT 14:00", "GMT 15:00",
        "GMT 16:00", "GMT 17:00", "GMT 18:00", "GMT 19:00",
        "GMT 20:00", "GMT 21:00", "GMT 22:00", "GMT 23:00"};

    /**
     * @return the HOUR_LIST
     */
    public static String[] getHourList() {
        return HOUR_LIST;
    }
}
